/** Automatically generated file. DO NOT MODIFY */
package com.commonsware.android.mapsv2.location;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}